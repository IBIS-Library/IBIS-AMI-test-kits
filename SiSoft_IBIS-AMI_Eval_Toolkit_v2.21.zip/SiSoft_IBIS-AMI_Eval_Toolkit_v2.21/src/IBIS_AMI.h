//
// IBIS_AMI.h
//
// Header file for generic IBIS AMI model
// 
// Copyright (c) 2007. Signal Integrity Software, Inc. (SiSoft)
// All Rights Reserved.
//
// History:
// 4 June 2007, Mike Steinberger: Split IBIS_AMI_Tx into two parts and added
//    the generic DLL declarations for Windoze.
// 22 May 2007, Mike Steinberger: Initial file creation
//
//
// Permission to use, copy, modify, and distribute this software and 
// associated documentation for educational, research and commercial 
// purposes, without fee and without a signed licensing agreement, is hereby
// granted, provided that the above copyright notice, this paragraph and
// the following three paragraphs appear in all copies, modifications, and
// distributions. 
//
// This is part of a sample IBIS Algorithmic Modeling Interface (AMI) model. 
// This code has been provided by SiSoft to help demonstrate and drive 
// adoption of the IBIS AMI modeling standard.  For more information
// on this and other IBIS AMI models, contact Signal Integrity Software, 
// 6 Clock Tower Place, Maynard, MA 01754, (978) 461-0449 or email
// ibis-ami@sisoft.com.
// 
// THIS MATERIAL IS PROVIDED FOR THE RECIPIENT'S USE AT THE RECIPIENT's OWN RISK.
// IN NO EVENT SHALL SISOFT BE LIABLE TO ANY PARTY FOR FOR ANY DIRECT,
// INDIRECT, INCIDENTAL,SPECIAL OR CONSEQUENTIAL DAMAGES, OR ANY OTHER DAMAGES 
// WHATSOEVER (INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, 
// BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) 
// ARISING OUT OF THE USE OR INABILITY TO USE THIS LICENSED MATERIAL, WHETHER 
// OR NOT THE POSSIBILITY OR CAUSE OF SUCH DAMAGES WAS KNOWN TO SISOFT.
// 
// SISOFT SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
// PARTICULAR PURPOSE. THIS SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
// ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS". SISOFT HAS NO OBLIGATION
// TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
// MODIFICATIONS.

#ifndef IBIS_AMI_INCLUDED
#define IBIS_AMI_INCLUDED

#ifdef _MSC_VER
//The following was copied from the Microsoft Visual Studio 6.0 headers.
// The following ifdef block is the standard way of creating macros which make
// exporting from a DLL simpler. All files within this DLL are compiled with
// the IBIS_AMI_EXPORTS symbol defined on the command line. Thsi symbol should
// not be defined on any project that uses this DLL. This way any other project
// whose source files include thisfile see IBIS_AMI_API functions as being
// imported from a DLL, whereas this DLL sees symbols defined with this macro
// as being exported.
#ifdef IBIS_AMI_EXPORTS
#define IBIS_AMI_API __declspec(dllexport)
#else
#define IBIS_AMI_API __declspec(dllimport)
#endif
//End of copy from our friends at Microsoft.
#else
#define IBIS_AMI_API
#endif //WINDOZE

IBIS_AMI_API long AMI_Init( double *impulse_matrix,
                            long row_size,
                            long aggressors,
                            double sample_interval,
                            double bit_time,
                            char *AMI_parameters_in,
                            char **AMI_parameters_out,
                            void **AMI_memory_handle,
                            char **msg );

IBIS_AMI_API long AMI_GetWave( double *wave_in,
                               long wave_size,
                               double *clock_times,
                               char **AMI_parameters_out,
                               void *AMI_memory );

IBIS_AMI_API long AMI_Close( void *AMI_memory );

#endif //IBIS_AMI_INCLUDED
