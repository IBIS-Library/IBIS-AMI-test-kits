/*
IBIS_AMI_CHGAIN.c
C.Kumar and Ambrish Varma
Dec 21 2007
This is a simple gain filter which just multiplies the input wave by the gain factor.
The purpose of this dll is to illustrate the channel sim  dll interface. 


� 2007 Cadence Design Systems, Inc.  All rights reserved  worldwide. 
The information and computer programs ("Licensed Material") contained herein 
are protected by copyright law and international treaties. Unauthorized 
reproduction or distribution of the Licensed Material, or any portion of it, 
may result in severe civil and criminal penalties.  Cadence grants Recipient 
of the Licensed Material a limited, nonexclusive,  personal, right to use the
Licensed Material for Recipient's  internal use in evaluating Cadence software and 
hardware products.   In no event shall Recipient distribute the Licensed Material or 
use the Licensed Material for benchmarking purposes.    

The Licensed Material is provided to Recipient to use at Recipient's own risk.  
The Licensed Material may not be compatible with current or future versions of 
Cadence products.  THE LICENSED MATERIAL IS PROVIDED "AS IS" AND WITH NO WARRANTIES, 
INCLUDING WITHOUT LIMITATION ANY EXPRESS WARRANTIES OR IMPLIED WARRANTIES OF 
MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.   

IN NO EVENT SHALL CADENCE BE LIABLE TO RECIPIENT OR ANY THIRD PARTY FOR ANY INCIDENTAL, 
INDIRECT, SPECIAL OR CONSEQUENTIAL DAMAGES, OR ANY OTHER DAMAGES WHATSOEVER(INCLUDING, 
WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS 
OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING OUT OF THE USE OR INABILITY 
TO USE LICENSED MATERIAL, WHETHER OR NOT THE POSSIBILITY OR CAUSE OF SUCH DAMAGES WAS 
KNOWN TO CADENCE.
*/


#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

static void destroyGain (double *gain)
{
  if(!gain)
    return;

  if (gain)
    free (gain);

}

static long loadparams (double *gainval, char *sparams)
{
  char buff2[4000];
  char * x;
  int flag=0;

  if(!*gainval || !sparams)
    return 0;
  x = strtok(sparams," \n()"); 

  while(x!=NULL)  
  {
   x=strtok(NULL," \n()");

   if(x!=NULL)
     {
       strcpy(buff2,x);

     if(strcmp (x,"gain")==0)
       flag=1;

     if((flag==1)&&(atof(buff2)!=0))
       {
       *gainval = atof(buff2);
       }
     }
  }
  return 1;
}

__declspec(dllexport) long AMI_Init (double *impulse_matrix,

               long row_size,

               long aggressors, 

               double sample_interval,

               double bit_time,

               char *AMI_dll_parameters_in, 

               char **AMI_dll_parameters_out, 

               void **AMI_dll_memory_handle,

               char **msg)

{
  double *gain=0;
  double *val;
  char *temp_msg;
  *msg = calloc(2000, sizeof(*msg));
  temp_msg = *msg ;
 
  Cadence_Licence();
  
// since this is a 
//    simple gain filter no initialization is necessary

//    also there is no need to store any server information. so we will just
//    zero the dll_server_param_obj 
  
  if(AMI_dll_memory_handle)
    *AMI_dll_memory_handle = 0;

  if(!impulse_matrix)
    return 0;

  if(!AMI_dll_memory_handle)
    return 0;  

  gain = calloc (1, sizeof (*gain));

  if(!gain)
    return 0;

  *gain=2;
  
  sprintf(temp_msg," AMI_dll_parameters_in: '%s' \n",AMI_dll_parameters_in);

  if(!loadparams(val, AMI_dll_parameters_in))
    return 0;

  if(*val > 0)
      *gain = *val;
      
  printf("The value of gain used is :%f \n", *gain);

  *AMI_dll_memory_handle = gain;

  return 1; 
  // for success 
}

__declspec(dllexport) long AMI_GetWave (double *wave,

                  long wave_size,

                  double *clock_times,

                  char **AMI_dll_parameters_out,

                  void *AMI_dll_memory)

{
  long i=0;
  double *pgain=0;
  double gain=0;


  if(!wave || !AMI_dll_memory)
    return 0;

  pgain = AMI_dll_memory;
  gain = *pgain;

  for (i=0; i<wave_size; i++)
    wave [i] = gain * wave[i];

  return 1;

}

__declspec(dllexport) long AMI_Close(void * AMI_dll_memory)
{
  destroyGain (AMI_dll_memory);
  return 1;
}

int Cadence_Licence(void)
{
printf(" � 2007 Cadence Design Systems, Inc.  All rights reserved  worldwide.\n" 
"The information and computer programs (\"Licensed Material\") contained herein \n"
"are protected by copyright law and international treaties. Unauthorized \n"
"reproduction or distribution of the Licensed Material, or any portion of it, \n"
"may result in severe civil and criminal penalties.  Cadence grants Recipient \n"
"of the Licensed Material a limited, nonexclusive,  personal, right to use the \n"
"Licensed Material for Recipient's  internal use in evaluating Cadence software and \n"
"hardware products.   In no event shall Recipient distribute the Licensed Material or \n"
"use the Licensed Material for benchmarking purposes.   \n\n"
"The Licensed Material is provided to Recipient to use at Recipient's own risk.  \n"
"The Licensed Material may not be compatible with current or future versions of \n"
"Cadence products.  THE LICENSED MATERIAL IS PROVIDED \"AS IS\" AND WITH NO WARRANTIES, \n"
"INCLUDING WITHOUT LIMITATION ANY EXPRESS WARRANTIES OR IMPLIED WARRANTIES OF \n"
"MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  \n\n"
"IN NO EVENT SHALL CADENCE BE LIABLE TO RECIPIENT OR ANY THIRD PARTY FOR ANY INCIDENTAL, \n"
"INDIRECT, SPECIAL OR CONSEQUENTIAL DAMAGES, OR ANY OTHER DAMAGES WHATSOEVER(INCLUDING, \n"
"WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS \n"
"OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING OUT OF THE USE OR INABILITY \n"
"TO USE LICENSED MATERIAL, WHETHER OR NOT THE POSSIBILITY OR CAUSE OF SUCH DAMAGES WAS \n"
"KNOWN TO CADENCE. \n");
return 0;
}
